from django import forms
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import authenticate, get_user_model
from django.forms import ValidationError
from django.utils.translation import gettext as _
import re

User = get_user_model()

class CustomLoginForm(AuthenticationForm):
    error_messages = {
        'invalid_login': (
            "指定されたユーザー名とパスワードの組み合わせは正しくありません。"
            "もう一度確認して入力してください。"
        ),
        'inactive': "このアカウントは無効です。",
    }

    def clean_username(self):
        username = self.cleaned_data.get('username')

        # Check if username is alphanumeric
        if not bool(re.match('^[a-zA-Z]*$', username)):
            raise forms.ValidationError('Username can only contain alphabets.')

        # Check if username exists in the database
        if not User.objects.filter(username=username).exists():
            raise forms.ValidationError('Username does not exist.')

        return username

    def clean(self):
        username = self.cleaned_data.get('username')
        password = self.cleaned_data.get('password')

        if username and password:
            self.user_cache = authenticate(self.request, username=username, password=password)
            if self.user_cache is None:
                raise ValidationError(
                    _("指定されたユーザー名とパスワードの組み合わせは正しくありません。もう一度確認して入力してください。"),
                    code='invalid_login',
                    params={'username': self.username_field.verbose_name},
                )
            else:
                self.confirm_login_allowed(self.user_cache)

        return self.cleaned_data
