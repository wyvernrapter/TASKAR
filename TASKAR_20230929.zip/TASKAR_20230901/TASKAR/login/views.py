from django.contrib.auth.views import LoginView
from django.http import HttpResponseRedirect, request
from django.contrib.auth.forms import AuthenticationForm
from django.shortcuts import render
from django.urls import reverse_lazy
from .forms import CustomLoginForm
from django.contrib.auth import authenticate
from django import forms


class CustomLoginForm(AuthenticationForm):
    error_messages = {
        'invalid_login': _(
            "指定されたユーザー名とパスワードの組み合わせは正しくありません。"
            "もう一度確認して入力してください。"
        ),
        'inactive': _("このアカウントは無効です。"),
    }

    def clean(self):
        username = self.cleaned_data.get('username')
        password = self.cleaned_data.get('password')

        if username is not None and password:
            self.user_cache = authenticate(self.request, username=username, password=password)
            if self.user_cache is None:
                raise forms.ValidationError(
                    self.error_messages['invalid_login'],
                    code='invalid_login',
                    params={'username': self.username_field.verbose_name},
                )
            else:
                self.confirm_login_allowed(self.user_cache)

        return self.cleaned_data

class CustomLoginView(LoginView):
    template_name = 'login/login.html'
    form_class = CustomLoginForm

    def get(self, request):
        form = self.form_class(request=request)
        context = {
            'form': form,
        }
        return render(request, self.template_name, context)

    # def __init__(self, **kwargs):
    #     super().__init__(kwargs)
    #     self.session = None

    # def form_valid(self, form):
    #     response = super().form_valid(form)
    #     return response

    # def search_clear(request):
    #     if 'query' in request.session.keys():
    #         del request.session['query']
    #     if 'page' in request.session.keys():
    #         del request.session['page']
    #     return HttpResponseRedirect(reverse_lazy('index'))