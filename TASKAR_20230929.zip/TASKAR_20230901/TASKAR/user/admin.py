from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from .models import User, Trainee, Curriculum_List, Progress, Meeting

from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from django.core.exceptions import ObjectDoesNotExist
from .models import User, Trainee
from django.db import models
from django.core import validators

class TraineeInline(admin.StackedInline):  
    model = Trainee
    can_delete = False
    verbose_name_plural = '研修生'
    fk_name = 'user'  

# class CustomUserAdmin(BaseUserAdmin):
#     inlines = (TraineeInline, )
    
#     list_display = ('username', 'email', 'is_active', 'is_staff', 'admin', 'get_trainee_name', 'get_employee_number')
#     list_filter = ('admin', 'is_active')
#     ordering = ('email',)
#     search_fields = ('username', 'email',)

#     def get_trainee_name(self, instance):
#         try:
#             return instance.trainee.name
#         except ObjectDoesNotExist:
#             return "None"
#     get_trainee_name.short_description = '研修生名'
    
#     def get_employee_number(self, instance):
#         try:
#             return instance.trainee.employee_number
#         except ObjectDoesNotExist:
#             return "None"
#     get_employee_number.short_description = '社員番号'



class UserAdmin(BaseUserAdmin):
    list_display = ("username", "email", "is_active", "is_staff", "admin")
    list_filter = ("admin", "is_active")
    ordering = ("email",)
    filter_horizontal = ()
    search_fields = ('username', 'email',)  # username を検索対象に追加
    
    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('username', 'email', 'password1', 'password2')}
        ),
    )
    
    fieldsets = (
        (None, {'fields': ('username', 'email', 'password')}),
        ('Permissions', {'fields': ('is_active', 'is_staff', 'is_superuser', 'groups', 'user_permissions')}),
    )


admin.site.register(User, UserAdmin)


@admin.register(Trainee)
class TraineeAdmin(admin.ModelAdmin):
    class Meta:
        verbose_name = '研修生'
        verbose_name_plural = '研修生'

@admin.register(Curriculum_List)
class CurriculumAdmin(admin.ModelAdmin):
    class Meta:
        verbose_name = 'カリキュラム'
        verbose_name_plural = 'カリキュラム'

@admin.register(Progress)
class ProgressAdmin(admin.ModelAdmin):
    class Meta:
        verbose_name = '進捗管理'
        verbose_name_plural = '進捗管理'

@admin.register(Meeting)
class MeetDayAdmin(admin.ModelAdmin):
    class Meta:
        verbose_name = '面談申請'
        verbose_name_plural = '面談申請'


