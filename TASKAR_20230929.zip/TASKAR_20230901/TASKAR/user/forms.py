from django import forms
from betterforms.multiform import MultiModelForm
from django.core.exceptions import ValidationError
from django.core.validators import RegexValidator
import datetime
from datetime import date, timedelta
from .models import User, Trainee, Curriculum_List, Progress
import re
from dateutil.relativedelta import relativedelta
from django.utils.translation import gettext as _

class User_Form(forms.ModelForm):
    class Meta:
        model = User
        fields = ['username', 'password', 'email']  # 必要なフィールドに合わせて変更

class CustomCheckboxInput(forms.CheckboxInput):
    option_template_name = 'custom_checkbox_input.html'


# ------------------------------------------------------------------------------------------------------------------------------
# ------------------------------------------------------------------------------------------------------------------------------

# 研修生
# 管理画面
class Trainee_Form(forms.ModelForm):
    class Meta:
        model = Trainee
        #exclude = ['user']
        fields = '__all__'
        widgets = {
            'gender': forms.Select(choices=Trainee.GENDER_CHOICES, attrs={'class': 'form-control'}),
            'employment': forms.Select(choices=Trainee.EMPLOYMENT_CHOICES, attrs={'class': 'form-control'}),
            'status': forms.Select(choices=Trainee.STATUS_CHOICES, attrs={'class': 'form-control'}),
            }


    user_login_name = forms.ModelChoiceField(
        queryset=User.objects.all(),
        label="User",
        required=True,
        widget=forms.Select(attrs={'class': 'form-control'}),
        #to_field_name="username"  # Traineeモデルのnameフィールドに基づいて選択を行う
    )


    name_trainee = forms.CharField(
        required=True,
        widget=forms.TextInput(attrs={'class': 'form-control'}),
        error_messages={'invalid': '数字と記号は入力出来ません。'},
        )
    

    birth_day = forms.DateField(
        required=True,
        input_formats=['%Y-%m-%d'],
        widget=forms.DateInput(attrs={'class': 'form-control'}),
        )
    
    employee_number_trainee = forms.IntegerField(
        min_value=0,
        max_value=99999,
        widget=forms.NumberInput(attrs={'class': 'form-control'})
        )
    
    joining_date = forms.DateField(
        required=True,
        input_formats=['%Y-%m-%d'],
        widget=forms.DateInput(attrs={'class': 'form-control'}),
        )
    
    employee_email_01 = forms.EmailField(
        widget=forms.EmailInput(attrs={'class': 'form-control'}),
        error_messages={'invalid': '有効なEメールアドレスを入力してください。'},
        required=False
        )
    
    employee_email_02 = forms.EmailField(
        widget=forms.EmailInput(attrs={'class': 'form-control'}),
        error_messages={'invalid': '有効なEメールアドレスを入力してください。'},
        required=False
        )
    
    training_start = forms.DateField(
        required=True,
        input_formats=['%Y-%m-%d'],
        widget=forms.DateInput(attrs={'class': 'form-control'}),
        )
    
    training_period = forms.IntegerField(
        min_value=0,
        max_value=36,
        initial=0,
        widget=forms.NumberInput(attrs={'class': 'form-control'})
        ) 
    
    training_end = forms.DateField(
        input_formats=['%Y-%m-%d'],
        widget=forms.DateInput(attrs={'class': 'form-control'}),
        required=False
        )
    
    training_end_expected = forms.DateField(
        input_formats=['%Y-%m-%d'],
        widget=forms.DateInput(attrs={'class': 'form-control'}),
        required=False
        # disabled=True  # 自動計算する。ユーザーは直接変更できない
        )

# バリデーションエラー

    def clean_name_trainee(self):
        name_trainee = self.cleaned_data['name_trainee']

        if not name_trainee or name_trainee.strip() == '':
            raise forms.ValidationError(_("入力してください"),code='invalid name')
        if re.search(r'[0-9]', name_trainee) or re.search(r'[!@#$%^&*\-()_+={};:\'",.<>?/|\\]', name_trainee):
            raise forms.ValidationError(_('数字と記号は入力出来ません'),code='invalid name')
        
        return name_trainee

    def clean_employee_email_01(self):
        employee_email_01 = self.cleaned_data['employee_email_01']
        
        # 簡単なメールアドレスの正規表現
        email_regex = r"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$"
        
        if not re.match(email_regex, employee_email_01):
            raise forms.ValidationError('有効なEメールアドレスの形式を入力してください。')
        return employee_email_01

    def clean_employee_email_02(self):
        employee_email_02 = self.cleaned_data['employee_email_02']

        # 簡単なメールアドレスの正規表現
        email_regex = r"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$"
        
        if not re.match(email_regex, employee_email_02):
            raise forms.ValidationError('有効なEメールアドレスの形式を入力してください。')
        return employee_email_02
    


class Curriculum_List_Form(forms.ModelForm):

    class Meta:
        model = Curriculum_List
        fields = '__all__'
        widgets = {
            'course': forms.TextInput(attrs={'class': 'form-control'}),
            'curriculum': forms.TextInput(attrs={'class': 'form-control'}),
            'curriculum_url': forms.TextInput(attrs={'class': 'form-control'}),

            'chapter_name_01': forms.TextInput(attrs={'class': 'form-control'}),
            'chapter_name_02': forms.TextInput(attrs={'class': 'form-control'}),
            'chapter_name_03': forms.TextInput(attrs={'class': 'form-control'}),
            'chapter_name_04': forms.TextInput(attrs={'class': 'form-control'}),
            'chapter_name_05': forms.TextInput(attrs={'class': 'form-control'}),
            'chapter_name_06': forms.TextInput(attrs={'class': 'form-control'}),
            'chapter_name_07': forms.TextInput(attrs={'class': 'form-control'}),
            'chapter_name_08': forms.TextInput(attrs={'class': 'form-control'}),
            'chapter_name_09': forms.TextInput(attrs={'class': 'form-control'}),
            'chapter_name_10': forms.TextInput(attrs={'class': 'form-control'}),
            'chapter_name_11': forms.TextInput(attrs={'class': 'form-control'}),
            'chapter_name_12': forms.TextInput(attrs={'class': 'form-control'}),
            'chapter_name_13': forms.TextInput(attrs={'class': 'form-control'}),
            'chapter_name_14': forms.TextInput(attrs={'class': 'form-control'}),
            'chapter_name_15': forms.TextInput(attrs={'class': 'form-control'}),

            'assignment_url_01': forms.TextInput(attrs={'class': 'form-control'}),
            'assignment_url_02': forms.TextInput(attrs={'class': 'form-control'}),
            'assignment_url_03': forms.TextInput(attrs={'class': 'form-control'}),
            'assignment_url_04': forms.TextInput(attrs={'class': 'form-control'}),
            'assignment_url_05': forms.TextInput(attrs={'class': 'form-control'}),
            'assignment_url_06': forms.TextInput(attrs={'class': 'form-control'}),
            'assignment_url_07': forms.TextInput(attrs={'class': 'form-control'}),
            'assignment_url_08': forms.TextInput(attrs={'class': 'form-control'}),
            'assignment_url_09': forms.TextInput(attrs={'class': 'form-control'}),
            'assignment_url_10': forms.TextInput(attrs={'class': 'form-control'}),
            'assignment_url_11': forms.TextInput(attrs={'class': 'form-control'}),
            'assignment_url_12': forms.TextInput(attrs={'class': 'form-control'}),
            'assignment_url_13': forms.TextInput(attrs={'class': 'form-control'}),
            'assignment_url_14': forms.TextInput(attrs={'class': 'form-control'}),
            'assignment_url_15': forms.TextInput(attrs={'class': 'form-control'}),

            'assignment_file_01': forms.FileInput(attrs={'class': 'form-control'}),
            'assignment_file_01': forms.FileInput(attrs={'class': 'form-control'}), 
            'assignment_file_02': forms.FileInput(attrs={'class': 'form-control'}),
            'assignment_file_03': forms.FileInput(attrs={'class': 'form-control'}),
            'assignment_file_04': forms.FileInput(attrs={'class': 'form-control'}),
            'assignment_file_05': forms.FileInput(attrs={'class': 'form-control'}),
            'assignment_file_06': forms.FileInput(attrs={'class': 'form-control'}),
            'assignment_file_07': forms.FileInput(attrs={'class': 'form-control'}),
            'assignment_file_08': forms.FileInput(attrs={'class': 'form-control'}),
            'assignment_file_09': forms.FileInput(attrs={'class': 'form-control'}),
            'assignment_file_10': forms.FileInput(attrs={'class': 'form-control'}),
            'assignment_file_11': forms.FileInput(attrs={'class': 'form-control'}),
            'assignment_file_12': forms.FileInput(attrs={'class': 'form-control'}),
            'assignment_file_13': forms.FileInput(attrs={'class': 'form-control'}),
            'assignment_file_14': forms.FileInput(attrs={'class': 'form-control'}),
            'assignment_file_15': forms.FileInput(attrs={'class': 'form-control'})
        }

    curriculum_period = forms.FloatField(label="受講目安期間", initial="0", widget=forms.NumberInput(attrs={'class':'form-control'}))

    chapter_total_number = forms.IntegerField(
        initial=0,
        min_value=0,
        max_value=15,
        widget=forms.NumberInput(attrs={'class': 'form-control'})
        )
    
# ------------------------------------------------------------------------------------------------------
# ------------------------------------------------------------------------------------------------------


class Progress_Form(forms.ModelForm):

    user_login_name = forms.ModelChoiceField(
        queryset=User.objects.all(),
        label="ログインユーザーネーム",
        required=True,
        widget=forms.Select(attrs={'class': 'form-control'}),
        #to_field_name="name"  # Traineeモデルのnameフィールドに基づいて選択を行う
    )

    trainee = forms.ModelChoiceField(
        queryset=Trainee.objects.all(),
        label="研修生一覧",
        required=True,
        widget=forms.Select(attrs={'class': 'form-control'}),
        #to_field_name="name"  # Traineeモデルのnameフィールドに基づいて選択を行う
    )

    curriculum = forms.ModelChoiceField(
        queryset=Curriculum_List.objects.all(),
        label="カリキュラム一覧",
        required=True,
        widget=forms.Select(attrs={'class': 'form-control'}),
        #to_field_name="curriculum"  # Curriculum_Listモデルのcurriculumフィールドに基づいて選択を行う
    )

    attendance_period = forms.IntegerField(
        min_value=0,
        max_value=36,
        initial=0,
        widget=forms.NumberInput(attrs={'class': 'form-control'})
        )

    attendance_start = forms.DateField(
        required=True,
        input_formats=['%Y-%m-%d'],
        widget=forms.DateInput(attrs={'class': 'form-control'}),
        )
    
    attendance_end_expected = forms.DateField(
        input_formats=['%Y-%m-%d'],
        widget=forms.DateInput(attrs={'class': 'form-control'}),
        # required=True,
        # disabled=True  # 自動計算する。ユーザーは直接変更できない
        )
    
    # 修了
    completion = forms.BooleanField(required=False, widget=forms.CheckboxInput())


    # 進捗率
    progress_rate = forms.CharField(
        required=False,
        widget=forms.TextInput(attrs={'class': 'form-control'}),
        # required=True,
        # disabled=True  # 自動計算する。ユーザーは直接変更できない
        )


    def __init__(self, *args, **kwargs):
        super(Progress_Form, self).__init__(*args, **kwargs)
        
        # ここで、Curriculum_Listから最初のレコードのchapter_total_numberを取得します。
        # 実際のロジックはあなたのニーズに応じて変更してください。
        curriculum = Curriculum_List.objects.first()
        if curriculum:
            self.fields['chapter_total_number'].initial = curriculum.chapter_total_number
    
    chapter_total_number = forms.IntegerField(
        label="章の数",
        required=True,
        widget=forms.NumberInput(attrs={'class': 'form-control'}),
    )


    chapter1_complete = forms.BooleanField(required=False, widget=CustomCheckboxInput())
    chapter2_complete = forms.BooleanField(required=False, widget=CustomCheckboxInput())
    chapter3_complete = forms.BooleanField(required=False, widget=CustomCheckboxInput())
    chapter4_complete = forms.BooleanField(required=False, widget=forms.CheckboxInput())
    chapter5_complete = forms.BooleanField(required=False, widget=forms.CheckboxInput())
    chapter6_complete = forms.BooleanField(required=False, widget=forms.CheckboxInput())
    chapter7_complete = forms.BooleanField(required=False, widget=forms.CheckboxInput())
    chapter8_complete = forms.BooleanField(required=False, widget=forms.CheckboxInput())
    chapter9_complete = forms.BooleanField(required=False, widget=forms.CheckboxInput())
    chapter10_complete = forms.BooleanField(required=False, widget=forms.CheckboxInput())
    chapter11_complete = forms.BooleanField(required=False, widget=forms.CheckboxInput())
    chapter12_complete = forms.BooleanField(required=False, widget=forms.CheckboxInput())
    chapter13_complete = forms.BooleanField(required=False, widget=forms.CheckboxInput())
    chapter14_complete = forms.BooleanField(required=False, widget=forms.CheckboxInput())
    chapter15_complete = forms.BooleanField(required=False, widget=forms.CheckboxInput())


    def clean(self):
        cleaned_data = super().clean()
        curriculum_completion = cleaned_data.get("curriculum_completion")
        
        # curriculum_completionがTrueになっている場合
        if curriculum_completion:
            # 今日の日付をcurriculum_completion_dateに設定
            cleaned_data["curriculum_completion_date"] = date.today()
        
        return cleaned_data

    def save(self, commit=True):
        instance = super().save(commit=False)
        
        # curriculum_completionがTrueの場合、curriculum_completion_dateを更新
        if self.cleaned_data["curriculum_completion"]:
            instance.curriculum_completion_date = date.today()
        
        if commit:
            instance.save()
        return instance



    class Meta:
        model = Progress
        fields = '__all__'

    
    # def clean(self):
    #     cleaned_data = super().clean()
    #     selected_curriculum = cleaned_data.get('curriculum')
        
    #     # curriculum_period_eachに選択されたcurriculumのcurriculum_periodを設定
    #     if selected_curriculum:
    #         cleaned_data['curriculum_period_each'] = selected_curriculum.curriculum_period
        
    #     return cleaned_data

# ------------------------------------------------------------------------------------------------------------------------------
# ------------------------------------------------------------------------------------------------------------------------------
# 面談申請
from django import forms
from .models import Meeting
from django.utils import timezone

class Meeting_Form(forms.ModelForm):
    application_date = forms.DateField(
        widget=forms.DateInput(attrs={'readonly': 'readonly', 'value': timezone.localtime(timezone.now()).date(), 'class': 'form-control'}),
        initial=timezone.localtime(timezone.now()).date()
    )

    class Meta:
        model = Meeting
        fields = '__all__'  # すべてのフィールドをフォームに追加
        widgets = {
            'trainee': forms.Select(attrs={'class': 'form-control'}),
            'user_login_name': forms.Select(attrs={'class': 'form-control'}),
            'meeting_topic': forms.Select(attrs={'class': 'form-control'}),
            'response': forms.CheckboxInput(attrs={'class': 'form-control'}),
        }


class UpdateMeetingResponseForm(forms.ModelForm):
    class Meta:
        model = Meeting
        fields = ['response']



# ------------------------------------------------------------------------------------------------------------------------------
# ------------------------------------------------------------------------------------------------------------------------------


