import uuid
import datetime
from django.db import models
from django.core import validators
from calendar import monthrange
from dateutil.relativedelta import relativedelta
from django.contrib.auth.models import AbstractUser
from django.contrib.auth.validators import UnicodeUsernameValidator
from django.core.validators import RegexValidator
from django.db import models
from django.core.validators import FileExtensionValidator # ファイルをアップデートされたときのバリデーション
from datetime import date
from django.utils import timezone


# from django.contrib.auth.models import AbstractUser, BaseUserManager
# from django.utils.translation import ugettext_lazy as _
# from django.db import models

# class CustomUserManager(BaseUserManager):
#     """Define a model manager for User model with no username field."""

#     def create_user(self, email, password=None, **extra_fields):
#         """Create and return a new user."""
#         if not email:
#             raise ValueError(_('The Email field must be set'))
#         email = self.normalize_email(email)
#         user = self.model(email=email, **extra_fields)
#         user.set_password(password)
#         user.save(using=self._db)
#         return user

#     def create_superuser(self, email, password=None, **extra_fields):
#         """Create and return a new super user."""
#         extra_fields.setdefault('is_staff', True)
#         extra_fields.setdefault('is_superuser', True)
#         return self.create_user(email, password, **extra_fields)

# class User(AbstractUser):
#     username = None
#     email = models.EmailField(_('email address'), unique=True)

#     USERNAME_FIELD = 'email'
#     REQUIRED_FIELDS = []

#     objects = CustomUserManager()

#     def __str__(self):
#         return self.email

from django.contrib.auth.models import AbstractUser, UnicodeUsernameValidator
from django.db import models
from django.core.validators import RegexValidator
import uuid

class User(AbstractUser):
    username_validator = UnicodeUsernameValidator()

    class Role(models.IntegerChoices):
        MANAGEMENT = 0
        GENERAL = 1
        PART_TIME = 2

    # 不要なフィールドはNoneにすることができる
    first_name = None
    last_name = None
    date_joined = None

    is_active = models.BooleanField(default=True)
    is_staff = models.BooleanField(default=False)
    admin = models.BooleanField(default=False)
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    
    employee_number = models.CharField(
        unique=False,
        validators=[RegexValidator(r"^[0-9]{5}$")],
        max_length=8,
        verbose_name="社員番号",
    )
    
    username = models.CharField(
        max_length=50,
        unique=True,
        validators=[username_validator],
    )
    email = models.EmailField(max_length=254, unique=True)
    role = models.PositiveIntegerField(
        choices=Role.choices, default=Role.PART_TIME
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    # デフォルトはusername
    USERNAME_FIELD = "username"
    # uniqueのemailとusernameを指定
    REQUIRED_FIELDS = ["email"]

    # 変更前の名前はUsers
    class Meta:
        ordering = ["employee_number"]
        db_table = "User"
        verbose_name = 'ユーザー登録'
        verbose_name_plural = 'ユーザー登録'

    def __str__(self):
        return self.username

    

# カスタムユーザクラスを定義
# ------------------------------------------------------------------------------------------------------------------------------
# ------------------------------------------------------------------------------------------------------------------------------
# 管理者　研修生一覧
class Trainee(models.Model):
    GENDER_CHOICES = (
        ('男性', '男性'),
        ('女性', '女性'),
        ('その他', 'その他')
    )

    EMPLOYMENT_CHOICES = (
        ('正社員', '正社員'),
        ('契約', '契約'),
    )

    STATUS_CHOICES = (
        ('研修生', '研修生'),
        ('卒業生', '卒業生'),
        ('リタイア', 'リタイア'),
    )

    user_login_name = models.OneToOneField(User, on_delete=models.CASCADE, verbose_name='ログインユーザーネーム', null=True)

    name_trainee = models.CharField(
        max_length=50,
        verbose_name='研修生名',
        validators=[validators.RegexValidator(r'^[^\d]*$', '数字は入力できません。')]
    )

    gender = models.CharField(
        max_length=5,
        choices=GENDER_CHOICES,
        verbose_name='性別'
    )

    birth_day = models.DateField(
        null=True,
        verbose_name='誕生日'
    )

    employee_number_trainee = models.CharField(
        max_length=20,
        null=True,
        verbose_name='社員番号',
        validators=[validators.RegexValidator(r'^[a-zA-Z0-9]*$', '半角英数字以外は入力できません。')]
    )

    employment = models.CharField(
        max_length=10,
        blank=True,
        choices=EMPLOYMENT_CHOICES,
        verbose_name='雇用形態'
    )

    joining_date = models.DateField(
        verbose_name='入社日'
    )

    employee_email_01 = models.EmailField(
        null=True,
        blank=True,
        verbose_name='社員メールアドレス１',
        validators=[validators.EmailValidator('メールアドレスの形式で入力してください。')]
    )

    employee_email_02 = models.EmailField(
        null=True,
        blank=True,
        verbose_name='社員メールアドレス２',
        validators=[validators.EmailValidator('メールアドレスの形式で入力してください。')]
        )

    training_start = models.DateField(
        verbose_name='研修開始日',
        blank=True,
        null=True
        )

    training_period = models.PositiveSmallIntegerField(
        verbose_name='研修期間',
        default = 6
        )

    
    # 研修修了予定日（表示OFF）
    training_end_expected = models.DateField(
        verbose_name='研修修了予定日',
        blank=True,
        null=True
        )


    # 研修修了日
    training_end = models.DateField(
        verbose_name='研修修了日',
        blank=True,
        null=True
        )

    status = models.CharField(
        max_length=10,
        choices=STATUS_CHOICES,
        verbose_name='ステータス'
        )


    # アラート（表示は、進捗・アラート画面）
    # 最初は、デフォルトでON
    alert_set = models.BooleanField(
        verbose_name='アラート',
        default=False
        )


    def __str__(self):
        # Djangoの管理者画面のデータの名前を反映させるコード
        return self.name_trainee
        # return '{} - {}'.format(self.name, self.age)

    # 変更前の名前は研修生・管理者
    class Meta:
        verbose_name = '研修生登録'
        verbose_name_plural = '研修生登録'


# 管理者　研修生一覧
# ------------------------------------------------------------------------------------------------------------------------------
# ------------------------------------------------------------------------------------------------------------------------------
# 管理者　カリキュラム一覧
class Curriculum_List(models.Model):

    def upload_file_name(instance, filename):
        return f"uploads/{filename}"
    

    course = models.CharField(
        max_length=30,
        verbose_name='コース'
        )
    

    curriculum = models.CharField(
        max_length=30,
        verbose_name='カリキュラム'
        )
    curriculum_url = models.URLField(
        verbose_name='カリキュラムURL',
        blank=True,
        null=True,
        validators=[validators.URLValidator(message='正しいURLを入力してください。')]
        )
    
    curriculum_period = models.FloatField(
        verbose_name='受講目安期間',
        default='3',
        validators=[
            validators.MinValueValidator(0, '0以上の半角数字を入力してください。'),
            validators.MaxValueValidator(36, '36以下の半角数字を入力してください。')
        ]
    )

    # 作成日（自動入力）
    create_date = models.DateField(
        verbose_name='作成日',
        auto_now_add=True
        )

    # 最終更新日（自動入力）
    edit_date = models.DateField(
        verbose_name='最終更新日',
        auto_now=True
        )

    chapter_total_number = models.IntegerField(
        verbose_name='章の数',
        default=1,
        blank=True,
        null=True,
        validators=[validators.validate_integer]
        )

    chapter_number_01 = models.IntegerField(
        verbose_name='章１_number',
        blank=True,
        null=True,
        validators=[validators.validate_integer]
        )
    chapter_name_01 = models.CharField(
        max_length=30,
        blank=True,
        verbose_name='章１_name'
        )
    assignment_url_01 = models.URLField(
        verbose_name='章１　課題URL',
        blank=True,
        null=True,
        validators=[validators.URLValidator(message='正しいURLを入力してください。')]
        )
    assignment_file_01 = models.FileField(
        null=True,
        blank=True,
        upload_to=upload_file_name,
        validators=[FileExtensionValidator(['pdf','docx','doc','xlsx','xls','pptx','ppt','txt','zip'])]
        )

    curriculum_number_02 = models.IntegerField(
        verbose_name='章２_number',
        validators=[validators.validate_integer],
        blank=True,
        null=True
        )
    chapter_name_02 = models.CharField(
        max_length=30,
        blank=True,
        verbose_name='章２_name'
        )
    assignment_url_02 = models.URLField(
        verbose_name='章２　課題URL',
        validators=[validators.URLValidator(message='正しいURLを入力してください。')],
        blank=True,
        null=True
        )
    assignment_file_02 = models.FileField(
        null=True,
        blank=True,
        upload_to=upload_file_name,
        validators=[FileExtensionValidator(['pdf','docx','doc','xlsx','xls','pptx','ppt','txt','zip'])]
        )
    

    curriculum_number_03 = models.IntegerField(
        verbose_name='章３_number',
        validators=[validators.validate_integer],
        blank=True,
        null=True
        )
    chapter_name_03 = models.CharField(
        max_length=30,
        blank=True,
        verbose_name='章３_name'
        )
    assignment_url_03 = models.URLField(
        verbose_name='章３　課題URL',
        validators=[validators.URLValidator(message='正しいURLを入力してください。')],
        blank=True,
        null=True
        )
    assignment_file_03 = models.FileField(
            null=True,
            blank=True,
            upload_to=upload_file_name,
            validators=[FileExtensionValidator(['pdf','docx','doc','xlsx','xls','pptx','ppt','txt','zip'])]
        )
    
    curriculum_number_04 = models.IntegerField(
        verbose_name='章４_number',
        validators=[validators.validate_integer],
        blank=True,
        null=True
        )
    chapter_name_04 = models.CharField(
        max_length=30,
        blank=True,
        verbose_name='章４_name'
        )
    assignment_url_04 = models.URLField(
        verbose_name='章４　課題URL',
        validators=[validators.URLValidator(message='正しいURLを入力してください。')],
        blank=True,
        null=True
        )
    assignment_file_04 = models.FileField(
        null=True,
        blank=True,
        upload_to=upload_file_name,
        validators=[FileExtensionValidator(['pdf','docx','doc','xlsx','xls','pptx','ppt','txt','zip'])]
        )

    curriculum_number_05 = models.IntegerField(
        verbose_name='章５_number',
        validators=[validators.validate_integer],
        blank=True,
        null=True
        )
    chapter_name_05 = models.CharField(
        max_length=30,
        blank=True,
        verbose_name='章５_name'
        )
    assignment_url_05 = models.URLField(
        verbose_name='章５　課題URL',
        validators=[validators.URLValidator(message='正しいURLを入力してください。')],
        blank=True,
        null=True
        )
    assignment_file_05 = models.FileField(
        null=True,
        blank=True,
        upload_to=upload_file_name,
        validators=[FileExtensionValidator(['pdf','docx','doc','xlsx','xls','pptx','ppt','txt','zip'])]
        )

    curriculum_number_06 = models.IntegerField(
        verbose_name='章６_number',
        validators=[validators.validate_integer],
        blank=True,
        null=True
        )
    chapter_name_06 = models.CharField(
        max_length=30,
        blank=True,
        verbose_name='章６_name'
        )
    assignment_url_06 = models.URLField(
        verbose_name='章６　課題URL',
        validators=[validators.URLValidator(message='正しいURLを入力してください。')],
        blank=True,
        null=True
        )
    assignment_file_06 = models.FileField(
        null=True,
        blank=True,
        upload_to=upload_file_name,
        validators=[FileExtensionValidator(['pdf','docx','doc','xlsx','xls','pptx','ppt','txt','zip'])]
        )

    curriculum_number_07 = models.IntegerField(
        verbose_name='章７_number',
        validators=[validators.validate_integer],
        blank=True,
        null=True
        )
    chapter_name_07 = models.CharField(
        max_length=30,
        blank=True,
        verbose_name='章７_name'
        )
    assignment_url_07 = models.URLField(
        verbose_name='章７　課題URL',
        validators=[validators.URLValidator(message='正しいURLを入力してください。')],
        blank=True,
        null=True
        )
    assignment_file_07 = models.FileField(
        null=True,
        blank=True,
        upload_to=upload_file_name,
        validators=[FileExtensionValidator(['pdf','docx','doc','xlsx','xls','pptx','ppt','txt','zip'])]
        )

    curriculum_number_08 = models.IntegerField(
        verbose_name='章８_number',
        validators=[validators.validate_integer],
        blank=True,
        null=True
        )
    chapter_name_08 = models.CharField(
        max_length=30,
        blank=True,
        verbose_name='章８_name'
        )
    assignment_url_08 = models.URLField(
        verbose_name='章８　課題URL',
        validators=[validators.URLValidator(message='正しいURLを入力してください。')],
        blank=True,
        null=True
        )
    assignment_file_08 = models.FileField(
        null=True,
        blank=True,
        upload_to=upload_file_name,
        validators=[FileExtensionValidator(['pdf','docx','doc','xlsx','xls','pptx','ppt','txt','zip'])]
        )


    curriculum_number_09 = models.IntegerField(
        verbose_name='章９_number',
        validators=[validators.validate_integer],
        blank=True,
        null=True
        )
    chapter_name_09 = models.CharField(
        max_length=30,
        blank=True,
        verbose_name='章９_name'
        )
    assignment_url_09 = models.URLField(
        verbose_name='章９　課題URL',
        validators=[validators.URLValidator(message='正しいURLを入力してください。')],
        blank=True,
        null=True
        )
    assignment_file_09 = models.FileField(
        null=True,
        blank=True,
        upload_to=upload_file_name,
        validators=[FileExtensionValidator(['pdf','docx','doc','xlsx','xls','pptx','ppt','txt','zip'])]
        )
    
    curriculum_number_10 = models.IntegerField(
        verbose_name='章１０_number',
        validators=[validators.validate_integer],
        blank=True,
        null=True
        )
    chapter_name_10 = models.CharField(
        max_length=30,
        blank=True,
        verbose_name='章１０_name'
        )
    assignment_url_10 = models.URLField(
        verbose_name='章１０　課題URL',
        validators=[validators.URLValidator(message='正しいURLを入力してください。')],
        blank=True,
        null=True
        )
    assignment_file_10 = models.FileField(
        null=True,
        blank=True,
        upload_to=upload_file_name,
        validators=[FileExtensionValidator(['pdf','docx','doc','xlsx','xls','pptx','ppt','txt','zip'])]
        )

    curriculum_number_11 = models.IntegerField(
        verbose_name='章１１_number',
        validators=[validators.validate_integer],
        blank=True,
        null=True
        )
    chapter_name_11 = models.CharField(
        max_length=30,
        blank=True,
        verbose_name='章１１_name'
        )
    assignment_url_11 = models.URLField(
        verbose_name='章１１　課題URL',
        validators=[validators.URLValidator(message='正しいURLを入力してください。')],
        blank=True,
        null=True
        )
    assignment_file_11 = models.FileField(
        null=True,
        blank=True,
        upload_to=upload_file_name,
        validators=[FileExtensionValidator(['pdf','docx','doc','xlsx','xls','pptx','ppt','txt','zip'])]
        )


    curriculum_number_12 = models.IntegerField(
        verbose_name='章１２_number',
        validators=[validators.validate_integer],
        blank=True,
        null=True
        )
    chapter_name_12 = models.CharField(
        max_length=30,
        blank=True,
        verbose_name='章１２_name'
        )
    assignment_url_12 = models.URLField(
        verbose_name='章１２　課題URL',
        validators=[validators.URLValidator(message='正しいURLを入力してください。')],
        blank=True,
        null=True
        )
    assignment_file_12 = models.FileField(
        null=True,
        blank=True,
        upload_to=upload_file_name,
        validators=[FileExtensionValidator(['pdf','docx','doc','xlsx','xls','pptx','ppt','txt','zip'])]
        )

    curriculum_number_13 = models.IntegerField(
        verbose_name='章１３_number',
        validators=[validators.validate_integer],
        blank=True,
        null=True
        )
    chapter_name_13 = models.CharField(
        max_length=30,
        blank=True,
        verbose_name='章１３_name'
        )
    assignment_url_13 = models.URLField(
        verbose_name='章１３　課題URL',
        validators=[validators.URLValidator(message='正しいURLを入力してください。')],
        blank=True,
        null=True
        )
    assignment_file_13 = models.FileField(
        null=True,
        blank=True,
        upload_to=upload_file_name,
        validators=[FileExtensionValidator(['pdf','docx','doc','xlsx','xls','pptx','ppt','txt','zip'])]
        )

    curriculum_number_14 = models.IntegerField(
        verbose_name='章１４_number',
        validators=[validators.validate_integer],
        blank=True,
        null=True
        )
    chapter_name_14 = models.CharField(
        max_length=30,
        blank=True,
        verbose_name='章１４_name'
        )
    assignment_url_14 = models.URLField(
        verbose_name='章１４　課題URL',
        validators=[validators.URLValidator(message='正しいURLを入力してください。')],
        blank=True,
        null=True
        )
    assignment_file_14 = models.FileField(
        null=True,
        blank=True,
        upload_to=upload_file_name,
        validators=[FileExtensionValidator(['pdf','docx','doc','xlsx','xls','pptx','ppt','txt','zip'])]
        )
    
    curriculum_number_15 = models.IntegerField(
        verbose_name='章１５_number',
        validators=[validators.validate_integer],
        blank=True,
        null=True
        )
    chapter_name_15 = models.CharField(
        max_length=30,
        blank=True,
        verbose_name='章１５_name'
        )
    assignment_url_15 = models.URLField(
        verbose_name='章１５　課題URL',
        validators=[validators.URLValidator(message='正しいURLを入力してください。')],
        blank=True,
        null=True
        )
    assignment_file_15 = models.FileField(
        null=True,
        blank=True,
        upload_to=upload_file_name,
        validators=[FileExtensionValidator(['pdf','docx','doc','xlsx','xls','pptx','ppt','txt','zip'])]
        )

    # カリキュラム
    def __str__(self):
        return f"{self.course} - {self.curriculum}"

    class Meta:
        verbose_name = 'カリキュラム'
        verbose_name_plural = 'カリキュラム'


# 管理者　カリキュラム一覧
# ------------------------------------------------------------------------------------------------------------------------------
# ------------------------------------------------------------------------------------------------------------------------------
# 管理者　進捗リスト
# TraineeとCurriculum_Listの中間テーブル
class Progress(models.Model):
    trainee = models.ForeignKey(Trainee, verbose_name='研修生一覧', on_delete=models.CASCADE)
    curriculum = models.ForeignKey(Curriculum_List, verbose_name='カリキュラム一覧', on_delete=models.CASCADE)


    user_login_name = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name='ログインユーザーネーム', null=True)


    attendance_period = models.FloatField(
        verbose_name='受講期間',
        #default='3',
        validators=[
            validators.MinValueValidator(0, '0以上の半角数字を入力してください。'),
            validators.MaxValueValidator(36, '36以下の半角数字を入力してください。')
        ],
        blank=True,
        null=True
    )

    # 受講開始日
    attendance_start = models.DateField(
        verbose_name='受講開始日',
        blank=True,
        null=True
        )
    
    # 受講修了予定日
    attendance_end_expected = models.DateField(
        verbose_name='受講修了予定日',
        blank=True,
        null=True
        )
    
    # 進捗率
    progress_rate = models.IntegerField(
        verbose_name='進捗率',
        validators=[validators.validate_integer],
        blank=True,
        null=True
        )
    
    # 進捗期間率
    progress_date_rate = models.IntegerField(
        verbose_name='進捗期間率',
        validators=[validators.validate_integer],
        blank=True,
        null=True
        )
    
    # 進捗遅延率
    progress_delay = models.IntegerField(
        verbose_name='進捗遅延率',
        validators=[validators.validate_integer],
        blank=True,
        null=True
        )
    
    # 章完了数
    completed_chapters = models.IntegerField(
        verbose_name='章完了数',
        validators=[validators.validate_integer],
        blank=True,
        null=True
        )


# 完了日
    chapter1_complete_date = models.DateField(blank=True, null=True)
    chapter2_complete_date = models.DateField(blank=True, null=True)
    chapter3_complete_date = models.DateField(blank=True, null=True)
    chapter4_complete_date = models.DateField(blank=True, null=True)
    chapter5_complete_date = models.DateField(blank=True, null=True)
    chapter6_complete_date = models.DateField(blank=True, null=True)
    chapter7_complete_date = models.DateField(blank=True, null=True)
    chapter8_complete_date = models.DateField(blank=True, null=True)
    chapter9_complete_date = models.DateField(blank=True, null=True)
    chapter10_complete_date = models.DateField(blank=True, null=True)
    chapter11_complete_date = models.DateField(blank=True, null=True)
    chapter12_complete_date = models.DateField(blank=True, null=True)
    chapter13_complete_date = models.DateField(blank=True, null=True)
    chapter14_complete_date = models.DateField(blank=True, null=True)
    chapter15_complete_date = models.DateField(blank=True, null=True)


    # 完了チェック
    chapter1_complete = models.BooleanField(default=False)
    chapter2_complete = models.BooleanField(default=False)
    chapter3_complete = models.BooleanField(default=False)
    chapter4_complete = models.BooleanField(default=False)
    chapter5_complete = models.BooleanField(default=False)
    chapter6_complete = models.BooleanField(default=False)
    chapter7_complete = models.BooleanField(default=False)
    chapter8_complete = models.BooleanField(default=False)
    chapter9_complete = models.BooleanField(default=False)
    chapter10_complete = models.BooleanField(default=False)
    chapter11_complete = models.BooleanField(default=False)
    chapter12_complete = models.BooleanField(default=False)
    chapter13_complete = models.BooleanField(default=False)
    chapter14_complete = models.BooleanField(default=False)
    chapter15_complete = models.BooleanField(default=False)
        

    def save(self, *args, **kwargs):

        completed_chapters = sum([
            self.chapter1_complete,
            self.chapter2_complete,
            self.chapter3_complete,
            self.chapter4_complete,
            self.chapter5_complete,
            self.chapter6_complete,
            self.chapter7_complete,
            self.chapter8_complete,
            self.chapter9_complete,
            self.chapter10_complete,
            self.chapter11_complete,
            self.chapter12_complete,
            self.chapter13_complete,
            self.chapter14_complete,
            self.chapter15_complete
        ])

        total_chapters = self.curriculum.chapter_total_number
        self.progress_rate = int((completed_chapters / total_chapters) * 100)

        self.completed_chapters = completed_chapters

        if self.attendance_start and self.attendance_end_expected:
            # 受講の全期間の日数を計算
            total_days = (self.attendance_end_expected - self.attendance_start).days
            # 現在の日付から受講開始日を引いた日数を計算
            progress_days = (date.today() - self.attendance_start).days
            # 進捗期間を計算（全期間の日数で割る）
            # total_daysが0になることを防ぐための条件も設定
            self.progress_date_rate = (progress_days / total_days) * 100 if total_days != 0 else 0

        # progress_delayの計算
        if self.progress_date_rate is not None and self.progress_rate is not None:
            self.progress_delay = self.progress_date_rate - self.progress_rate

        super(Progress, self).save(*args, **kwargs)



    # 修了（表示は、進捗・アラート画面）
    # 最初は、デフォルトでFalse
    curriculum_completion = models.BooleanField(
        default = False,
        help_text='修了Falseで、アラートリストに表示',
        blank=True
        )

    # 修了日
    curriculum_completion_date = models.DateField(blank=True, null=True)


    def __str__(self):
        return f"{self.curriculum.course} - {self.curriculum.curriculum}"

    class Meta:
        verbose_name = '進捗管理'
        verbose_name_plural = '進捗管理'

# ------------------------------------------------------------------------------------------------------------------------------
# ------------------------------------------------------------------------------------------------------------------------------

assignment_file = models.FileField(
    upload_to='uploads/',
    verbose_name='課題_%Y%m%d-%H%M%S',
    validators=[FileExtensionValidator(['pdf','docx','doc','xlsx','xls','pptx','ppt','txt','zip'])]
    )

# ------------------------------------------------------------------------------------------------------------------------------
# ------------------------------------------------------------------------------------------------------------------------------
# # 面談申請
# # Traineeテーブルとの連携
class Meeting(models.Model):
    trainee = models.ForeignKey(Trainee, verbose_name='研修生一覧', on_delete=models.CASCADE)
    
    MEETING_CHOICES = (
        ('カリキュラム', 'カリキュラム'),
        ('実務・現場', '実務・現場'),
        ('メンター面談', 'メンター面談'),
        ('その他', 'その他')
    )

    user_login_name = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name='ログインユーザーネーム', blank=True, null=True)

    meeting_topic = models.CharField(
        max_length=15,
        choices=MEETING_CHOICES,
        verbose_name='面談内容',
        blank=True,
        null=True
    )

    application_date = models.DateField(
        verbose_name='申請日',
        default=timezone.now().date(),
    )

    response = models.BooleanField(
        default=False,
        help_text='対応したらTrue',
        blank=True
    )


    class Meta:
        verbose_name = '面談管理'
        verbose_name_plural = '面談管理'


