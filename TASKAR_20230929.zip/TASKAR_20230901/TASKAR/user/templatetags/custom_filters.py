from django import template

register = template.Library()

@register.filter(name='getattr')
def get_attr(obj, attr_name):
    return getattr(obj, attr_name, None)

@register.filter(name='getattribute')
def getattribute(value, arg):
    """Gets an attribute of an object dynamically from a string name"""
    return getattr(value, arg)


@register.filter
def rangefilter(value):
    return range(value)


@register.filter(name='dynamic_attr')
def dynamic_attr(obj, attribute_base_name):
    full_attribute_name = f"{attribute_base_name}{obj.curriculum.chapter_total_number}_complete"
    return getattr(obj, full_attribute_name, False)


@register.filter(name='invert_number')
def invert_number(value):
    return -value


#---------------------------------------------------------------
# カリキュラム用
@register.filter(name='getattribute')
def getattribute(value, arg):
    """Gets an attribute of an object dynamically from a string name"""
    return getattr(value, arg)

@register.filter
def get_last_part(value, delimiter='_'):
    return value.split(delimiter)[-1]
