from django import template

register = template.Library()

@register.filter
def get_item(value, arg):
    try:
        idx = int(arg)
        if 0 <= idx < len(value):
            return value[idx]
    except ValueError:
        pass
    return ""
