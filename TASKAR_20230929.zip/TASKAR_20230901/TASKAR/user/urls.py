from django.urls import path
from .views import MemberView, Member_Create_View, Member_Update_View, CurriculumView, CurriculumCreateView, CurriculumUpdateView, CurriculumUserView, \
    Meeting_Create_View, UserDashboardView, Alert_View, Progress_View, Progress_Register_View, Progress_Update_View, Progress_User_View, Dashbord_View , \
    DashboardRedirectView, CurriculumFileDeleteView, CurriculumUrlView

from . import views

app_name = 'user'
urlpatterns = [
    path('', DashboardRedirectView.as_view(), name='dashboard-redirect'),
    path('dashboard/', Dashbord_View.as_view(), name='dashboard'),
    path('list/', MemberView.as_view(), name="member_list"),
    path('curriculum/', CurriculumView.as_view(), name="curriculum"),
    path('curriculum/register/', CurriculumCreateView.as_view(), name='curriculum_create'),
    path('curriculum/update/<int:pk>/', CurriculumUpdateView.as_view(), name='curriculum_update'),
    path('curriculum/delete_file/<int:pk>/<int:file_num>/', CurriculumFileDeleteView.as_view(), name='delete_file'),
    path('error_page/<str:error_info>/', views.error_page_view, name='error_page'),
    path('curriculum_link/<int:pk>/<int:file_num>/', views.CurriculumLinkView.as_view(), name='curriculum_link'),
    path('download_file/<int:pk>/<int:file_num>/', views.DownloadFileView.as_view(), name='download_file'),
    path('curriculum_url/<int:pk>/', CurriculumUrlView.as_view(), name='curriculum_url'),
    path('register/', Member_Create_View.as_view(), name="member_register"),
    path('register/<int:pk>/', Member_Update_View.as_view(), name="member_register"),
    path('progress/', Progress_View.as_view(), name="progress"),
    path('progress_register/', views.add_progress, name='progress_register'),
    path('progress_register/<int:pk>/', Progress_Update_View.as_view(), name="progress_update"),
    path('alert/', Alert_View.as_view(), name="alert"),
    path('trainee_info/<int:trainee_id>/', views.trainee_info, name='trainee_info'),
    path('progress_user/', Progress_User_View.as_view(), name="progress_user"),
    path('progress_user/', views.progress_user_info, name='progress_user'),
    path('user_curriculum/', CurriculumUserView.as_view(), name="user_curriculum"),
    path('user_curriculum/', views.curriculum_user_info, name='user_curriculum'),
    path('user_dashboard/', UserDashboardView.as_view(), name="user_dashboard"),
    path('progress_user/', views.progress_view, name='progress_user'),
    path('user_dashboard/', views.progress_user_info, name='user_dashboard'),
    path('user_meeting/', Meeting_Create_View.as_view(), name="user_meeting"),
]

