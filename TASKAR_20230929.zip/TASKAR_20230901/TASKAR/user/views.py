from django.contrib.auth.mixins import LoginRequiredMixin
from django.http import request,FileResponse, HttpResponse,HttpResponseBadRequest
from django.shortcuts import render, get_object_or_404, redirect,redirect
from django.urls import reverse
from django.views import generic, View
from django.views.decorators.csrf import csrf_protect
from .forms import User_Form, Trainee_Form, Curriculum_List_Form, Progress_Form,Meeting_Form, UpdateMeetingResponseForm
from .models import User, Trainee, Curriculum_List, Progress, Meeting
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator
from django.contrib import messages
from datetime import date
import re
import datetime
import logging
import os

@csrf_protect
@login_required
def my_view(request):
    pass


# 不正コード防止用バリデーション
def is_valid_input(value):
    """Check if input contains any code-like strings."""
    patterns = [
        r"<script.*?>.*?</script>",   # simple script tags
        r"[$&+,:;=?@#|'<>.^*()%!-]",  # special characters
        r"function\s*?\(",            # JavaScript function declarations
        r"var\s+[\w]+",               # JavaScript variable declarations
    ]
    for pattern in patterns:
        if re.search(pattern, value, re.IGNORECASE):
            return False
    return True

# 年月日形式検証関数
def is_valid_date_format(date_str):
    pattern = re.compile(r'^\d{4}-\d{2}-\d{2}$')
    return bool(pattern.match(date_str))


# ------------------------------------------------------------------------------------------------------
@login_required
def trainee_info(request, trainee_id=None):
    trainee = None
    progress = None
    if request.user.is_authenticated:
        try:
            if trainee_id:
                trainee = Trainee.objects.get(id=trainee_id)
            else:
                trainee = Trainee.objects.get(user_login_name=request.user)

            progress = Progress.objects.filter(user_login_name=trainee.user_login_name)
            
        except Trainee.DoesNotExist:
            pass

    context = {
            'trainee': trainee,
            'progress': progress,
            'use_admin_member_style': True,
            'title': '研修生詳細',
            'title2': '面談履歴',
            'title3': '適性'
        }
    return render(request, 'user/trainee_info.html', context)

@login_required
def progress_user_info(request):
    trainee = None
    progress = None
    if request.user.is_authenticated:
        try:
            trainee = Trainee.objects.get(user_login_name=request.user)
            progress = Progress.objects.filter(user_login_name=request.user)
        except Trainee.DoesNotExist:
            pass

    context = {
            'trainee': trainee,
            'progress': progress,
        }
    return render(request, 'user/progress_user.html', context)

@login_required
def curriculum_user_info(request):
    trainee = None
    progress = None
    if request.user.is_authenticated:
        try:
            trainee = Trainee.objects.get(user_login_name=request.user)
            progress = Progress.objects.filter(user_login_name=request.user)
        except Trainee.DoesNotExist:
            pass

    context = {
            'trainee': trainee,
            'progress': progress,
        }
    return render(request, 'user/user_curriculum.html', context)


@login_required
def meeting_user_info(request):
    meeting = None
    if request.user.is_authenticated:
        try:
            meeting = Meeting.objects.filter(user_login_name=request.user)
        except Meeting.DoesNotExist:
            pass

    context = {
            'meeting': meeting,
        }
    return render(request, 'user/user_meeting.html', context)

# ------------------------------------------------------------------------------------------------------
# 研修生

class MemberView(View):
    template_name = 'user/member_list.html'

    # 日付フォーマットチェック関数
    def is_valid_date(self, date_str):
        try:
            datetime.datetime.strptime(date_str, '%Y-%m-%d')
            return True
        except ValueError:
            return False

    def get(self, request):
        trainees = Trainee.objects.all().order_by('-id')
        error_message = None    # ここでエラーメッセージを初期化
                
        # request.GET.get()を使用してクエリパラメータ0 を取得
        name = request.GET.get('name_trainee', "")
        training_start = request.GET.get('training_start', "")
        training_end = request.GET.get('training_end', "")
        status = request.GET.get('course', "")
        # order_select = request.GET.get('select')

        # 「元に戻る」ボタン出現条件
        search_performed = False

        # 年月日形式検証
        if training_start and not self.is_valid_date(training_start):
            error_message = "研修開始日の形式が正しくないか存在しない日です" 
        if training_end and not self.is_valid_date(training_end):
            error_message = "研修修了日の形式が正しくないか存在しない日です"
        
        
        if error_message:
            request.session['error_message'] = error_message  # エラーメッセージをセッションに保存
            return redirect('user:member_list')  # view_nameにリダイレクト

        # パラメータが存在する場合、フィルタを適用
        if name:
            trainees = trainees.filter(name_trainee__icontains=name)
            search_performed = True
        if training_start:
            trainees = trainees.filter(training_start=training_start)
            search_performed = True
        elif training_end:
            trainees = trainees.filter(training_end=training_end)
            search_performed = True
        if status:
            trainees = trainees.filter(status=status)
            search_performed = True
                
        # 選択ボックスの内容によってソート条件を追加
        # if order_select == "昇順":
        #     trainees = trainees.order_by('name')
        # elif order_select == "降順":
        #     trainees = trainees.order_by('-name')

        # ページネーションの設定
        paginator = Paginator(trainees, 100)  # Use filtered trainees for pagination
        page_number = request.GET.get("page")
        page_obj = paginator.get_page(page_number)

        error_message = request.session.pop('error_message', None)  # セッションから取得し、即時削除
            
        context = {
            'title': '研修生一覧',
            'names': 'ステータス',
            'search_title': '研修開始日',
            'search_title2': '研修修了日',
            'view_name': 'user:member_list',
            'trainees': page_obj,
            #'curriculum_data_all_user': curriculum_data_all_user,
            'page_obj': page_obj,
            'use_admin_member_style': True,
            'search_performed': search_performed,
            'name': name,
            'training_start': training_start,
            'training_end': training_end,
            'status':status,
            'error_message': error_message,
            'STATUS_CHOICES': Trainee.STATUS_CHOICES,
        }
        return render(request, self.template_name, context)
# 'order_select': order_select  # 選択内容をテンプレートに渡す


# 新規登録用のビュー
class Member_Create_View(View):
    template_name = 'user/member_register.html'
    form_class = Trainee_Form

    def get(self, request):
        form = self.form_class()
        context = {
            'form': form,
            'use_admin_member_style': True,
        }
        return render(request, self.template_name, context)

    def post(self, request):
        form = self.form_class(request.POST)
        context = {
            'form': form,
            'use_admin_member_style': True,
        }
        if form.is_valid():
            form.save()
            return redirect('user:member_list')
        return render(request, self.template_name, context)



# 既存データのアップデート用のビュー
class Member_Update_View(View):
    template_name = 'user/member_register.html'
    form_class_trainee = Trainee_Form
    form_class_user = User_Form

    def get(self, request, pk):
        trainee = get_object_or_404(Trainee, pk=pk) if pk else None
        form_trainee = self.form_class_trainee(instance=trainee)
        form_user = self.form_class_user(instance=trainee.user_login_name)

        context = {
            'form': form_trainee,
            'form_user': form_user,
            'use_admin_member_style': True,
            'show_delete_button': True if trainee else False
        }
        return render(request, self.template_name, context)

    def post(self, request, pk):
        trainee = get_object_or_404(Trainee, pk=pk) if pk else None
        user = trainee.user_login_name

        trainee_form = self.form_class_trainee(request.POST, instance=trainee)
        user_form = self.form_class_user(request.POST, instance=user)

        if 'delete' in request.POST:    
            if trainee:
                trainee.delete()
                return redirect('user:member_list')

        if user_form.is_valid() and trainee_form.is_valid():
            user_form.save()
            trainee_form.save()
            return redirect('user:member_list')
        
        # # ここでフォームのエラーをロギングまたは表示
        # print("User Form Errors:", user_form.errors)
        # print("Trainee Form Errors:", trainee_form.errors)

        context = {
            'user_form': user_form,
            'trainee_form': trainee_form
        }
        return render(request, self.template_name, context)
    
    class TraineeInfo(generic.TemplateView):
        template_name = 'user/trainee_info.html'


# ------------------------------------------------------------------------------------------------------
# ------------------------------------------------------------------------------------------------------
# カリキュラム

class CurriculumView(View):
    def get(self, request):
        # ページネーションの設定
        curriculum_data_all = Curriculum_List.objects.all().distinct()
        paginator = Paginator(Curriculum_List.objects.all().distinct().order_by('-create_date'), 100)
        page_number = request.GET.get("page")
        page_obj = paginator.get_page(page_number)

        chapter_attr_names = [
            'chapter_name_01',
            'chapter_name_02',
            'chapter_name_03',
            'chapter_name_04',
            'chapter_name_05',
            'chapter_name_06',
            'chapter_name_07',
            'chapter_name_08',
            'chapter_name_09',
            'chapter_name_10',
            'chapter_name_11',
            'chapter_name_12',
            'chapter_name_13',
            'chapter_name_14',
            'chapter_name_15'
            ]
        chapter_counts = [
            '第１章',
            '第２章',
            '第３章',
            '第４章',
            '第５章',
            '第６章',
            '第７章',
            '第８章',
            '第９章',
            '第１０章',
            '第１１章',
            '第１２章',
            '第１３章',
            '第１４章',
            '第１５章'
            ]

        context = {
            'title': 'カリキュラム一覧',
            'curriculum_data_all': curriculum_data_all,
            'curriculum_data_all': page_obj,
            'page_obj': page_obj,
            'view_name': 'user:curriculum',
            'use_admin_curriculum_style': True,
            'chapter_attr_names': chapter_attr_names,
            'chapter_counts': chapter_counts
        }
        return render(request, 'user/curriculum.html', context)

# 新規登録用のビュー
class CurriculumCreateView(View):
    template_name = 'user/curriculum_register.html'
    form_class = Curriculum_List_Form
    curriculum_data_all_user = Curriculum_List.objects.all().distinct()

    def get(self, request):
        form = self.form_class(request.POST, request.FILES)
        context = {
            'form': form,
            'use_admin_curriculum_style': True,
        }
        return render(request, self.template_name, context)

    def post(self, request):
        form = self.form_class(request.POST)
        context = {
            'form': form,
            'use_admin_curriculum_style': True,
        }
        if form.is_valid():
            form.save()
            return redirect('user:curriculum')
        return render(request, self.template_name, context)


# 既存データのファイルデータが順番に格納されていなかった時のビュー
def error_page_view(request, error_info):
    context = {
        'error_info': error_info,
        'use_admin_curriculum_style': True,
    }
    return render(request, 'user/error_info.html', context)

# 既存データのアップデート用のビュー
class CurriculumUpdateView(View):
    template_name = 'user/curriculum_register.html'
    form_class = Curriculum_List_Form

    def get(self, request, pk):
        try:
            curriculum = get_object_or_404(Curriculum_List, pk=pk)
            form = self.form_class(instance=curriculum)
            
            context = {
                'form': form,
                'use_admin_curriculum_style': True,
                'file_name': curriculum.assignment_file_01.name,
                'file_name_2': curriculum.assignment_file_02.name,
                'file_name_3': curriculum.assignment_file_03.name,
                'file_name_4': curriculum.assignment_file_04.name,
                'file_name_5': curriculum.assignment_file_05.name,
                'file_name_6': curriculum.assignment_file_06.name,
                'file_name_7': curriculum.assignment_file_07.name,
                'file_name_8': curriculum.assignment_file_08.name,
                'file_name_9': curriculum.assignment_file_09.name,
                'file_name_10': curriculum.assignment_file_10.name,
                'file_name_11': curriculum.assignment_file_11.name,
                'file_name_12': curriculum.assignment_file_12.name,
                'file_name_13': curriculum.assignment_file_13.name,
                'file_name_14': curriculum.assignment_file_14.name,
                'file_name_15': curriculum.assignment_file_15.name,
            }
            
            return render(request, self.template_name, context)
        
        except ValueError as e:
            return HttpResponseRedirect(reverse('user:error_page', args=[str(e)]))


    def post(self, request, pk):
        curriculum = get_object_or_404(Curriculum_List, pk=pk)
        form = self.form_class(request.POST, request.FILES, instance=curriculum)
        context = {
            'form': form,
            'use_admin_curriculum_style': True,
        }
        if form.is_valid():
            form.save()
            return redirect('user:curriculum')
        return render(request, self.template_name, context)

# 課題ダウンロード

class DownloadFileView(View):
    def get(self, request, pk, file_num):
        curriculum = get_object_or_404(Curriculum_List, pk=pk)
        attr_name = f'assignment_file_{file_num:02d}'
        file_field = getattr(curriculum, attr_name, None)

        if not file_field:
            return HttpResponse("File attribute not found.", status=404)

        file_path = file_field.path

        if os.path.exists(file_path):
            file = open(file_path, 'rb')
            original_filename = os.path.basename(file_field.name)
            
            # 拡張子を取得してMIMEタイプを決定する
            file_extension = os.path.splitext(original_filename)[1]
            
            if file_extension == '.docx':
                content_type = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
            elif file_extension == '.xlsx':
                content_type = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
            else:
                content_type = 'application/octet-stream'
            
            response = FileResponse(file, content_type=content_type)
            response['Content-Disposition'] = f'attachment; filename="{original_filename}"'
            return response
        else:
            return HttpResponse("File not found on server.", status=404)


    def download_file(request, pk, file_num):
        logger = logging.getLogger(__name__)


        attr_name = f'assignment_file_{file_num:02d}'
        logger.debug(f"Trying to get attribute with name: {attr_name}")

        file_field = getattr(Curriculum_List, attr_name, None)
        logger.debug(f"File field value: {file_field}")


# カリキュラムの章のリンク先処理
from django.http import HttpResponseRedirect

class CurriculumLinkView(View):
    def get(self, request, pk, file_num):
        curriculum = get_object_or_404(Curriculum_List, pk=pk)

        # 該当するassignment_urlを取得
        url_attr = f'assignment_url_{file_num:02d}'
        assignment_url = getattr(curriculum, url_attr, None)

        if assignment_url:
            return HttpResponseRedirect(assignment_url)
        else:
            return HttpResponse("URL not found for the given file number.", status=404)


# カリキュラムリンク先処理
class CurriculumUrlView(View):
    def get(self, request, pk):
        curriculum = get_object_or_404(Curriculum_List, pk=pk)

        # curriculum_urlを取得
        curriculum_url = curriculum.curriculum_url

        if curriculum_url:
            return HttpResponseRedirect(curriculum_url)
        else:
            return HttpResponse("URL not found for the given ID.", status=404)


# 課題削除処理
class CurriculumFileDeleteView(View):
    template_name = 'user/curriculum_register.html'
    
    def get(self, request, pk, file_num):
        curriculum = get_object_or_404(Curriculum_List, pk=pk)
        
        # 受け取ったファイル番号に基づいてファイルを削除
        file_attr = f'assignment_file_{file_num:02d}'
        file = getattr(curriculum, file_attr, None)
        if file:
            file.delete()

        # 保存してデータベースを更新
        curriculum.save()

        return redirect('user:curriculum')


# ------------------------------------------------------------------------------------------------------
# ------------------------------------------------------------------------------------------------------
# 進捗管理

class Progress_View(View):
    # 日付フォーマットチェック関数
    def is_valid_date(self, date_str):
        try:
            datetime.datetime.strptime(date_str, '%Y-%m-%d')
            return True
        except ValueError:
            return False

    def get(self, request):
        progress = Progress.objects.all().order_by('-id')
        trainees = Trainee.objects.all()
        courses = Curriculum_List.objects.all().distinct()
        error_message = None

        name = request.GET.get('name_trainee', "")
        training_start = request.GET.get('training_start', "")
        training_end = request.GET.get('training_end', "")
        course = request.GET.get('course', "")

        search_performed = False

        if training_start and not self.is_valid_date(training_start):
            error_message = "研修開始日の形式が正しくないか存在しない日です" 
        if training_end and not self.is_valid_date(training_end):
            error_message = "研修修了日の形式が正しくないか存在しない日です"

        if training_start and training_end:
            error_message = "開始日と修了日は同時に入力できません。"

        if error_message:
            request.session['error_message'] = error_message
            return redirect('user:progress')

        if name:
            progress = progress.filter(trainee__name_trainee__icontains=name)
            search_performed = True
        if training_start:
            progress = progress.filter(attendance_start=training_start)
            search_performed = True
        if training_end:
            progress = progress.filter(attendance_end_expected=training_end)
            search_performed = True
        if course:
            progress = progress.filter(curriculum__course=course)
            search_performed = True

        progress_list = progress.order_by('-id')
        paginator = Paginator(progress_list, 100)
        page_number = request.GET.get("page")
        page_obj = paginator.get_page(page_number)

        error_message = request.session.pop('error_message', None)

        context = {
            'title': '進捗管理',
            'search_title': '受講開始',
            'search_title2': '受講終了予定',
            'names': 'コース名',
            'trainees': trainees,
            'progress_list': page_obj,
            'page_obj': page_obj,
            'view_name': 'user:progress',
            'use_admin_progress_style': True,
            'search_performed': search_performed,
            'name': name,
            'courses': courses,
            'training_start': training_start,
            'training_end': training_end,
            'error_message': error_message,
        }
        return render(request, 'user/progress.html', context)



# 既存データのアップデート用のビュー
class Progress_Update_View(View):
    template_name = 'user/progress_register.html'
    form_class = Progress_Form

    def get(self, request, pk):
        progress = get_object_or_404(Progress, pk=pk)
        form = self.form_class(instance=progress)
        
        context = {
            'form': form,
            'use_admin_progress_style': True,
        }
        return render(request, self.template_name, context)

    def post(self, request, pk):
        progress = get_object_or_404(Progress, pk=pk)
        form = self.form_class(request.POST, request.FILES, instance=progress)
        if form.is_valid():
            form.save()
            return redirect('user:progress')
        context = {
            'form': form,
            'use_admin_progress_style': True,
        }
        return render(request, self.template_name, context)


class Progress_Register_View(View):

    def get(self, request, pk=None):
        progress = get_object_or_404(Progress, pk=pk) if pk else None
        form = Progress_Form(instance=progress)
        show_delete_button = True if progress else False
        
        # 特定のProgressインスタンスのtraineeのname属性を取得
        if progress:
            trainee_name = progress.trainee.name
        else:
            trainee_name = None

        context = {
            'form': form,
            'progress': progress,
            'trainee_name': trainee_name,  # contextにtrainee_nameを追加
            'use_admin_progress_style': True,
            'show_delete_button': show_delete_button
        }
        return render(request, 'user/progress_register.html', context)

    def post(self, request, pk=None):
        
        progress = None
        if pk:
            progress = get_object_or_404(Progress, pk=pk)

        # 削除処理
        if 'delete' in request.POST:    
            if progress:
                progress.delete()
                return redirect('user:progress')

        form = Progress_Form(request.POST or None, instance=progress)
        if form.is_valid():
            form.save()
            return redirect('user:progress')
        
        # formがvalidでない場合もtrainee_nameをcontextに追加する必要がある場合
        if progress:
            trainee_name = progress.trainee.name
        else:
            trainee_name = None

        context = {
            'form': form,
            'use_admin_progress_style': True,
            'trainee_name': trainee_name
        }
        return render(request, 'user/progress_register.html', context)


# ------------------------------------------------------------------------------------------------------
# ------------------------------------------------------------------------------------------------------

def add_progress(request):
    if request.method == 'POST':
        form = Progress_Form(request.POST)
        if form.is_valid():
            form.save()
            return redirect('user:progress')  # 保存後の遷移先URLを指定します。
    else:
        form = Progress_Form()

    context = {
        'form': form,
        'use_admin_progress_style': True,
        }
    return render(request, 'user/progress_register.html', context)


def progress(request):
    progress_data = Progress.objects.all()
    context = {'progress_list': progress_data}
    return render(request, 'user/progress.html', context)


# ------------------------------------------------------------------------------------------------------
# ------------------------------------------------------------------------------------------------------
# アラート

class Alert_View(View):

# 日付フォーマットチェック関数
    def is_valid_date(self, date_str):
        try:
            datetime.datetime.strptime(date_str, '%Y-%m-%d')
            return True
        except ValueError:
            return False

    def get(self, request):
        progress = Progress.objects.all().order_by('-progress_delay')
        trainees = Trainee.objects.all()
        courses = Curriculum_List.objects.all().distinct()
        error_message = None    # ここでエラーメッセージを初期化
                
        # request.GET.get()を使用してクエリパラメータ0 を取得
        name = request.GET.get('name_trainee', "")
        training_start = request.GET.get('training_start', "")
        training_end = request.GET.get('training_end', "")
        course = request.GET.get('course', "")
        # order_select = request.GET.get('select')

        # 「元に戻る」ボタン出現条件
        search_performed = False

        # 年月日形式検証
        if training_start and not self.is_valid_date(training_start):
            error_message = "研修開始日の形式が正しくないか存在しない日です" 
        if training_end and not self.is_valid_date(training_end):
            error_message = "研修修了日の形式が正しくないか存在しない日です"
        
        if error_message:
            request.session['error_message'] = error_message  # エラーメッセージをセッションに保存
            return redirect('user:alert')  # view_nameにリダイレクト

        # パラメータが存在する場合、フィルタを適用
        if name:
            progress = progress.filter(trainee__name_trainee__icontains=name)
            search_performed = True
        if training_start:
            progress = progress.filter(attendance_start=training_start)
            search_performed = True
        if training_end:
            progress = progress.filter(attendance_end_expected=training_end)
            search_performed = True
        if course:
            progress = progress.filter(curriculum__curriculum=course)
            search_performed = True
                
        # 選択ボックスの内容によってソート条件を追加
        # if order_select == "昇順":
        #     trainees = trainees.order_by('name')
        # elif order_select == "降順":
        #     trainees = trainees.order_by('-name')

        # ページネーションの設定
        paginator = Paginator(trainees, 100)  # Use filtered trainees for pagination
        page_number = request.GET.get("page")
        page_obj = paginator.get_page(page_number)

        error_message = request.session.pop('error_message', None)  # セッションから取得し、即時削除

        context = {
            'title': 'アラート',
            'names': 'カリキュラム',
            'search_title': '受講開始',
            'search_title2': '受講終了予定',
            'progress': progress,
            'page_obj': page_obj,
            'view_name': 'user:alert',
            'use_admin_alert_style': True,
            'search_performed': search_performed,
            'name': name,
            'courses': courses,
            'training_start': training_start,
            'training_end': training_end,
            'error_message': error_message,
        }
        return render(request, 'user/alert.html', context)
    

# ------------------------------------------------------------------------------------------------------
# ------------------------------------------------------------------------------------------------------
# 管理者画面
# ホーム

class DashboardRedirectView(View):
    def get(self, request, *args, **kwargs):
        if request.user.is_superuser:
            return redirect('dashboard/', permanent=True)
        else:
            return redirect('user_dashboard/', permanent=True)


class Dashbord_View(View):
    template_name = "user/dashboard.html"

    def get(self, request):
        trainee_count = Trainee.objects.filter(status='研修生').count()
        graduate_count = Trainee.objects.filter(status='卒業生').count()
        retire_count = Trainee.objects.filter(status='リタイア').count()
        progress_list = Progress.objects.order_by('-progress_delay')

        # name_trainee = Trainee.objects.filter(status='研修生')
        # meeting_topic = Meeting.objects.filter(status='面談内容')
        meetings = Meeting.objects.all()

        context = {
            'trainee_count': trainee_count,
            'graduate_count': graduate_count,
            'retire_count': retire_count,
            'progress_list': progress_list,

            'meetings': meetings,
        }

        return render(request, self.template_name, context)


    def post(self, request):
        if 'update_response' in request.POST:
            meeting_id = request.POST.get('meeting_id')
            try:
                meeting_instance = Meeting.objects.get(id=meeting_id)
                meeting_instance.response = True
                meeting_instance.save()
                return redirect('user:dashboard')
            except Meeting.DoesNotExist:
                pass  # エラーメッセージの追加や適切な処理が必要です
        
        form = self.form_class(request.POST)
        if form.is_valid():
            form.save()
            return redirect('user:dashboard')
        
        return render(request, self.template_name, {'form': form})


# ------------------------------------------------------------------------------------------------------------------------------
# ------------------------------------------------------------------------------------------------------------------------------

# 研修生画面
# ホーム

# 新規登録用のビュー

class UserDashboardView(View):
    template_name = 'user/user_dashboard.html'
    form_class = Meeting_Form
    meeting_data_user = None

    def get(self, request):
        meeting_data_user = Meeting.objects.filter(user_login_name=request.user).order_by('-id')
        progress_data_user = Progress.objects.filter(user_login_name=request.user).order_by('-id')
        curriculum_data_all_user = Curriculum_List.objects.all().distinct()

        form = self.form_class()
        update_form = UpdateMeetingResponseForm()  # 追加

        context = {
            'form': form,
            'update_form': update_form,  # 追加
            'curriculum_data_all_user': curriculum_data_all_user,
            'progress_data_user': progress_data_user,
            'meeting_data_user': meeting_data_user,
        }
        return render(request, self.template_name, context)

    def post(self, request):
        if 'update_response' in request.POST:
            meeting_id = request.POST.get('meeting_id')
            try:
                meeting_instance = Meeting.objects.get(id=meeting_id)
                meeting_instance.response = True
                meeting_instance.save()
                return redirect('user:user_dashboard')
            except Meeting.DoesNotExist:
                pass  # エラーメッセージの追加や適切な処理が必要です
        
        form = self.form_class(request.POST)
        if form.is_valid():
            form.save()
            return redirect('user:user_dashboard')
        
        return render(request, self.template_name, {'form': form})



# ------------------------------------------------------------------------------------------------------------------------------
# ------------------------------------------------------------------------------------------------------------------------------
# 研修生画面
# 面談申請
# 新規登録用のビュー
class Meeting_Create_View(View):
    template_name = 'user/user_meeting.html'
    form_class = Meeting_Form
    meeting_data_user = None

    def get(self, request):
        meeting_data_user = Meeting.objects.filter(user_login_name=request.user)

        # ログインしているユーザーに対応する研修生のオブジェクトを取得
        try:
            trainee = Trainee.objects.get(user_login_name=request.user) 
        except Trainee.DoesNotExist:
            trainee = None

        # Set initial values for form
        form = self.form_class(initial={
            'user_login_name': request.user,
            'trainee': trainee.id if trainee else None  # ログインしているユーザーに対応する研修生のIDを初期値として設定
        })

        context = {
            'form': form,
            'use_user_meeting_style': True,
            'meeting_data_user': meeting_data_user,
            'trainee_name': trainee.name_trainee if trainee else "N/A"
        }
        return render(request, self.template_name, context)


    def post(self, request):
        form = self.form_class(request.POST)
        if form.is_valid():
            form.save()
            return redirect('user:user_dashboard')
        return render(request, self.template_name, {'form': form})



# ------------------------------------------------------------------------------------------------------
# 研修生画面
# カリキュラム一覧

class CurriculumUserView(View):
    def get(self, request):
        curriculum_data_all_user = Curriculum_List.objects.all().distinct().order_by('-id')
        chapter_attr_names = [f'chapter_number_{i:02}' for i in range(1, 16)]
        chapter_counts = list(range(1, 16))

        chapter_attr_names = [
            'chapter_name_01',
            'chapter_name_02',
            'chapter_name_03',
            'chapter_name_04',
            'chapter_name_05',
            'chapter_name_06',
            'chapter_name_07',
            'chapter_name_08',
            'chapter_name_09',
            'chapter_name_10',
            'chapter_name_11',
            'chapter_name_12',
            'chapter_name_13',
            'chapter_name_14',
            'chapter_name_15'
            ]
        chapter_counts = [
            '第１章',
            '第２章',
            '第３章',
            '第４章',
            '第５章',
            '第６章',
            '第７章',
            '第８章',
            '第９章',
            '第１０章',
            '第１１章',
            '第１２章',
            '第１３章',
            '第１４章',
            '第１５章',
            ]

        context = {
            'title': 'カリキュラム一覧',
            'curriculum_data_all_user': curriculum_data_all_user,
            'chapter_attr_names': chapter_attr_names,
            'chapter_counts': chapter_counts,
            'use_user_curriculum_style': True
        }
        return render(request, 'user/user_curriculum.html', context)

# ------------------------------------------------------------------------------------------------------
# ------------------------------------------------------------------------------------------------------
# 研修生画面
# 進捗リスト


class Progress_User_View(View):

    def get(self, request):
        trainee = Trainee.objects.get(user_login_name=request.user)
        progresses = Progress.objects.filter(user_login_name=request.user).order_by('-id')

        combined_progress_data = []
        for index, progress in enumerate(progresses):
            #print(index)
            chapter_statuses = [(index, i, getattr(progress, f"chapter{i}_complete", False)) for i in range(1, 16)]
            #print(chapter_statuses)
            date_statuses = [(index, i, getattr(progress, f"chapter{i}_complete_date", False)) for i in range(1, 16)]

            completed_chapters = [f"chapter{i}_complete" for i in range(1, 16)]
            completed_dates = [f"chapter{i}_complete_date" for i in range(1, 16)]
            chapter_counts = [f'第{i}章' for i in range(1, 16)]

            combined_progress_data.append({
                'index': index,
                'progress': progress,
                'chapter_statuses': chapter_statuses,
                'date_statuses': date_statuses,
                "completed_chapters" : completed_chapters,
                "completed_dates" : completed_dates,
                "chapter_counts" : chapter_counts,
            })


        context = {
            'title': '進捗リスト',
            'trainee': trainee,
            'progresses': progresses,
            'use_User_style': True,
            'combined_progress_data': combined_progress_data,
        }
        return render(request, 'user/progress_user.html', context)


    def post(self, request):
        # 対応するProgressオブジェクトを取得
        progresses = Progress.objects.filter(user_login_name=request.user).order_by('-id')  # もし1つ以上のProgressがある場合、適切にフィルタリングが必要です
        for index, progress in enumerate(progresses):
            # チェックボックスの名前を動的に生成して、チェックされているかを確認
            for i in range(1, 16):  # 15章までを考慮
                checkbox_name = f"chapter{i}_complete"
                checkbox_name_index = f"{index}_chapter{i}_complete"
                date_attribute = f"chapter{i}_complete_date"

                # POSTデータにcheckbox_nameが存在する場合はチェックされている。存在しない場合はチェックされていない。
                is_checked = checkbox_name_index in request.POST
                #print("is_checked ", is_checked)
                request_name = request.POST
                #print("request_name ", request_name)

                # 現在のcheckboxとdate_attributeの値を取得
                current_checkbox_value = getattr(progress, checkbox_name, False)
                #current_date_value = getattr(progress, date_attribute, None)
                #print("current_checkbox_value ", current_checkbox_value)

                if is_checked:
                    # もしもともとcheckboxがFalseだった場合のみ、dateを更新
                    if not current_checkbox_value:
                        setattr(progress, checkbox_name, True)
                        setattr(progress, date_attribute, date.today())  # 現在の日付に設定
                elif not is_checked:
                    # もしもともとcheckboxがTrueだった場合のみ、dateをリセット
                    if current_checkbox_value:
                        setattr(progress, checkbox_name, False)
                        setattr(progress, date_attribute, None)  # 日付をリセット

                progress.save()  # 変更をデータベースに保存

        # 処理が完了したら、進捗リストページにリダイレクト
        return redirect('user:progress_user')



def progress_view(request):
    progresses = Progress.objects.all()
    return render(request, 'progress_user.html', {'progresses': progresses})

